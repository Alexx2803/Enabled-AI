 Description
    An external application focusing on the marketing point of view which is integrated with a dashboard to provide interactive results through queries provided by the user. The app is hosted on the VERCEL application which can be accessed by https://cu-ai-model.vercel.app.
    


Built with:
✅ Next.js 13
✅ REACT JS-front end
✅ Langchain TypeScript integration
✅ PineconeDB as the knowledge store
✅ OpenAI API

🧞 Commands
All commands are run from the root of the project, from a terminal:

Command	Action
npm install	Installs dependencies
npm run prepare:data	Splits your PDF file under the /docs folder into chunks, embeds them, uploads them to Pinecone
npm run dev	Starts the local dev server at localhost:3000

🚸 Roadmap
✅ Added sources to the streamed chat bubble
✅ Added AI Based mutual connection feature
✅ Added option for users to upload their data to make model more intelligent